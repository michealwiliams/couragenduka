# @pixi/display

## Installation

```bash
npm install @pixi/display
```

## Usage

```js
import * as application from '@pixi/display';
```